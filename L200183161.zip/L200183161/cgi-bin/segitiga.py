def luas(x,y):
    A = 0.5*x*y
    return A
    
print '<!DOCTYPE HTML>'
print
print '''<html>
<head>
	<title>Index</title>
</head>
<body>
<div align="Left" class="card">
    <section id="Motto" class="section">
    <br>
    <br>
    <table border='0' align="left">
	<tr>
            <td><img src='Foto.jpg' width="300px" height="300px"></td>
	    <td width="50px"></td>
	    <td width="300px"><font size='5'><b><p>Self Identity</b></p></font>
    	<h2>Bangun Geometri</h2>
    	<p>Name Bangun: Segitiga</p>
    	<p>Dimensi 2D/3D : 2D</p>
    	<p>Rumus Luas : 0.5*a*b </p>
    	<p>Paramater 1 :12</p>
    	<p>Parameter 2 :12</p>
        <p>luas :</p>'''
print luas(x=12, y=12)
print'''</td>
	</tr>
	</table>
</section>'''
print '</body></html>'

