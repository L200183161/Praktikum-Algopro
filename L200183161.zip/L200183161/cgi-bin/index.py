print '<!DOCTYPE HTML>'
print
print '''<html>
<head>
	<title>Index</title>
</head>
<body>
<div align="Left" class="card">
    <section id="Motto" class="section">
    <br>
    <br>
    <table border='0' align="left">
	<tr>
            <td><img src='Foto.jpg' width="300px" height="300px"></td>
	    <td width="50px"></td>
	    <td width="300px"><font size='5'><b><p>Self Identity</b></p></font>
    	<p>Name: Donny Rizal</p>
    	<p>Address: Mendungan</p>
    	<p>DOB,BP: 15 August 2018, Rembang</p>
    	<p>Fav Tourist Attraction: Home</p>
    	<p>Motto: Sometime No Life is quite good enough</p>
    	</td>
	</tr>
	</table>
</section>
</body>
</html>'''
